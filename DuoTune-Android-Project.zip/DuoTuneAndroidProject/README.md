# DuoTune — projeto Android

DuoTune é um protótipo nativo para Android com interface escura/minimalista, lista de dispositivos Bluetooth pareados, atalho na tela inicial e player de arquivos de áudio locais.

## O que funciona nesta versão

- Lista os dispositivos já pareados com o telefone.
- Identifica os dispositivos que o Android informa como conectados pelo perfil de áudio A2DP.
- O botão do app abre as configurações Bluetooth oficiais do Android para o usuário escolher/conectar um dispositivo.
- Inclui um widget de tela inicial. O botão **Abrir** leva diretamente às configurações Bluetooth; tocar no restante do widget abre o DuoTune.
- Permite escolher um arquivo de áudio local e reproduzi-lo. O áudio sai pela rota selecionada no próprio Android.

## Limitação importante: dois fones ao mesmo tempo

O DuoTune **não consegue criar uma segunda saída Bluetooth** quando o Android/fabricante não oferece esse recurso. Aplicativos comuns não têm uma API pública para forçar o áudio A2DP de uma única sessão a tocar em dois fones Bluetooth genéricos ao mesmo tempo. A reprodução simultânea depende do suporte nativo do aparelho, do chipset e do tipo de fone. Por isso, esta versão não mostra uma falsa opção de “sincronizar dois fones”.

O widget também não conecta silenciosamente a um fone com um toque: o Android mantém a confirmação/seleção de conexão nas configurações do sistema. O widget é um atalho direto para essa tela.

## Como gerar o APK no Windows

1. Instale o **Android Studio** e, pelo SDK Manager, instale **Android SDK Platform 35** e **Android SDK Build-Tools 35**.
2. Confirme que o JDK 17 ou superior está disponível. O Android Studio normalmente já inclui um JDK compatível.
3. Extraia esta pasta no computador.
4. Abra o PowerShell dentro da pasta `DuoTuneAndroidProject` e execute:

   ```powershell
   .\build-apk.ps1
   ```

5. O APK de depuração, assinado automaticamente com a chave debug local, será copiado para `DuoTune-debug.apk` na raiz do projeto.
6. Transfira o APK para o Android e instale. Talvez seja necessário autorizar a instalação de aplicativos dessa origem nas configurações do sistema.

Também é possível abrir a pasta no Android Studio e executar **Build > Build APK(s)**.

## Requisitos técnicos

- Android 8.0 (API 26) ou superior.
- Permissão `BLUETOOTH_CONNECT` em Android 12 ou superior, solicitada pelo app para ler a lista de dispositivos pareados.
- `compileSdk 35`, Android Gradle Plugin 8.7.3 e Gradle 8.9.

## Privacidade

O projeto não contém analytics, anúncios, login, envio de dados ou serviços em nuvem. A seleção de música usa o seletor de arquivos do Android e a reprodução ocorre localmente.
