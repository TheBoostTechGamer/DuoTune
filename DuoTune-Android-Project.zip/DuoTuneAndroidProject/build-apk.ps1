$ErrorActionPreference = 'Stop'
$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$GradleVersion = '8.9'
$GradleRoot = Join-Path $env:LOCALAPPDATA "DuoTune\gradle-$GradleVersion"
$GradleExe = Join-Path $GradleRoot 'bin\gradle.bat'

# Detect Android SDK installed by Android Studio.
$Sdk = $env:ANDROID_HOME
if (-not $Sdk) { $Sdk = $env:ANDROID_SDK_ROOT }
if (-not $Sdk) { $Sdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
$AndroidJar = Join-Path $Sdk 'platforms\android-35\android.jar'
if (-not (Test-Path $AndroidJar)) {
    throw "Android SDK Platform 35 não encontrado em '$Sdk'. Instale Android SDK Platform 35 pelo SDK Manager do Android Studio e execute novamente."
}

# Write the local SDK path for Gradle without changing the shared project files.
$SdkForGradle = $Sdk.Replace('\', '\\')
Set-Content -Path (Join-Path $ProjectDir 'local.properties') -Value "sdk.dir=$SdkForGradle" -Encoding ASCII

# Download Gradle 8.9 only when it is not already present.
if (-not (Test-Path $GradleExe)) {
    $DownloadDir = Join-Path $env:LOCALAPPDATA 'DuoTune'
    New-Item -ItemType Directory -Force -Path $DownloadDir | Out-Null
    $ZipPath = Join-Path $DownloadDir "gradle-$GradleVersion-bin.zip"
    $Url = "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip"
    Write-Host "Baixando Gradle $GradleVersion..."
    Invoke-WebRequest -Uri $Url -OutFile $ZipPath
    Expand-Archive -Path $ZipPath -DestinationPath $DownloadDir -Force
}

Write-Host 'Compilando o DuoTune...'
Push-Location $ProjectDir
try {
    & $GradleExe --no-daemon assembleDebug
    if ($LASTEXITCODE -ne 0) { throw "Gradle terminou com código $LASTEXITCODE" }
    $BuiltApk = Join-Path $ProjectDir 'app\build\outputs\apk\debug\app-debug.apk'
    if (-not (Test-Path $BuiltApk)) { throw 'O APK não foi encontrado após a compilação.' }
    $OutputApk = Join-Path $ProjectDir 'DuoTune-debug.apk'
    Copy-Item $BuiltApk $OutputApk -Force
    Write-Host "APK criado: $OutputApk" -ForegroundColor Green
}
finally {
    Pop-Location
}
