#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
GRADLE_VERSION="8.9"
GRADLE_HOME="${HOME}/.duotune/gradle-${GRADLE_VERSION}"
GRADLE_BIN="${GRADLE_HOME}/bin/gradle"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-${HOME}/Android/Sdk}}"

if [[ ! -f "${SDK}/platforms/android-35/android.jar" ]]; then
  echo "Android SDK Platform 35 não encontrado em ${SDK}. Instale-o pelo Android Studio/SDK Manager." >&2
  exit 1
fi

mkdir -p "$(dirname "${GRADLE_HOME}")"
if [[ ! -x "${GRADLE_BIN}" ]]; then
  ZIP="$(dirname "${GRADLE_HOME}")/gradle-${GRADLE_VERSION}-bin.zip"
  curl -L "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip" -o "${ZIP}"
  mkdir -p "$(dirname "${GRADLE_HOME}")"
  unzip -q -o "${ZIP}" -d "$(dirname "${GRADLE_HOME}")"
fi

printf 'sdk.dir=%s\n' "${SDK}" > "${PROJECT_DIR}/local.properties"
"${GRADLE_BIN}" -p "${PROJECT_DIR}" --no-daemon assembleDebug
cp "${PROJECT_DIR}/app/build/outputs/apk/debug/app-debug.apk" "${PROJECT_DIR}/DuoTune-debug.apk"
echo "APK criado em ${PROJECT_DIR}/DuoTune-debug.apk"
