package com.duotune.app;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothA2dp;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQUEST_BLUETOOTH_PERMISSION = 41;
    private static final int REQUEST_AUDIO_FILE = 42;

    private TextView bluetoothStatus;
    private LinearLayout devicesContainer;
    private TextView trackName;
    private Button playPauseButton;

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothA2dp a2dpProxy;
    private boolean profileRequested = false;

    private MediaPlayer mediaPlayer;
    private boolean playerPrepared = false;

    private final BluetoothProfile.ServiceListener profileListener = new BluetoothProfile.ServiceListener() {
        @Override
        public void onServiceConnected(int profile, BluetoothProfile proxy) {
            if (profile == BluetoothProfile.A2DP) {
                a2dpProxy = (BluetoothA2dp) proxy;
                refreshBluetoothUi();
            }
        }

        @Override
        public void onServiceDisconnected(int profile) {
            if (profile == BluetoothProfile.A2DP) {
                a2dpProxy = null;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bluetoothStatus = findViewById(R.id.txtBluetoothStatus);
        devicesContainer = findViewById(R.id.devicesContainer);
        trackName = findViewById(R.id.txtTrackName);
        playPauseButton = findViewById(R.id.btnPlayPause);
        Button openBluetoothButton = findViewById(R.id.btnOpenBluetooth);
        Button chooseMusicButton = findViewById(R.id.btnChooseMusic);

        BluetoothManager manager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        if (manager != null) {
            bluetoothAdapter = manager.getAdapter();
        }

        openBluetoothButton.setOnClickListener(v -> openBluetoothSettings());
        chooseMusicButton.setOnClickListener(v -> chooseMusic());
        playPauseButton.setOnClickListener(v -> togglePlayback());

        if (hasBluetoothPermission()) {
            refreshBluetoothUi();
        } else {
            requestBluetoothPermission();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (hasBluetoothPermission()) {
            refreshBluetoothUi();
        }
    }

    private boolean hasBluetoothPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_BLUETOOTH_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_BLUETOOTH_PERMISSION) {
            if (hasBluetoothPermission()) {
                refreshBluetoothUi();
            } else {
                bluetoothStatus.setText("Permissão não concedida");
                showDeviceMessage("Permita o acesso Bluetooth para listar os dispositivos pareados.");
            }
        }
    }

    private void refreshBluetoothUi() {
        if (bluetoothAdapter == null) {
            bluetoothStatus.setText("Não disponível");
            showDeviceMessage("Este aparelho não disponibiliza Bluetooth.");
            return;
        }

        if (!hasBluetoothPermission()) {
            bluetoothStatus.setText("Permissão necessária");
            showDeviceMessage("Toque em permitir para consultar seus dispositivos pareados.");
            return;
        }

        try {
            if (!bluetoothAdapter.isEnabled()) {
                bluetoothStatus.setText("Desligado");
                showDeviceMessage("Ative o Bluetooth para consultar seus fones.");
                return;
            }

            bluetoothStatus.setText("Ligado");
            Set<String> connectedAddresses = getConnectedA2dpAddresses();
            Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
            devicesContainer.removeAllViews();

            if (pairedDevices == null || pairedDevices.isEmpty()) {
                showDeviceMessage("Nenhum dispositivo pareado. Use os controles do Android para adicionar um fone.");
            } else {
                for (BluetoothDevice device : pairedDevices) {
                    String name = safeDeviceName(device);
                    boolean connected = connectedAddresses.contains(device.getAddress());
                    addDeviceRow(name, connected ? "Conectado para áudio" : "Pareado", connected);
                }
            }

            if (!profileRequested) {
                profileRequested = true;
                bluetoothAdapter.getProfileProxy(this, profileListener, BluetoothProfile.A2DP);
            }
        } catch (SecurityException exception) {
            bluetoothStatus.setText("Acesso restrito");
            showDeviceMessage("O Android bloqueou a consulta dos dispositivos Bluetooth.");
        }
    }

    private Set<String> getConnectedA2dpAddresses() {
        Set<String> addresses = new HashSet<>();
        if (a2dpProxy == null || !hasBluetoothPermission()) {
            return addresses;
        }
        try {
            for (BluetoothDevice device : a2dpProxy.getConnectedDevices()) {
                addresses.add(device.getAddress());
            }
        } catch (SecurityException ignored) {
            // A lista de dispositivos pareados continua disponível mesmo se o perfil A2DP não responder.
        }
        return addresses;
    }

    private String safeDeviceName(BluetoothDevice device) {
        try {
            String name = device.getName();
            return (name == null || name.trim().isEmpty()) ? "Dispositivo Bluetooth" : name;
        } catch (SecurityException exception) {
            return "Dispositivo Bluetooth";
        }
    }

    private void showDeviceMessage(String message) {
        devicesContainer.removeAllViews();
        TextView row = new TextView(this);
        row.setText(message);
        row.setTextColor(getColor(R.color.text_secondary));
        row.setTextSize(12);
        row.setPadding(dp(13), dp(14), dp(13), dp(14));
        row.setBackgroundResource(R.drawable.bg_card_alt);
        devicesContainer.addView(row, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private void addDeviceRow(String name, String state, boolean connected) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(13), dp(11), dp(13), dp(11));
        row.setBackgroundResource(R.drawable.bg_card_alt);

        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        TextView deviceName = new TextView(this);
        deviceName.setText(name);
        deviceName.setTextColor(getColor(R.color.text_primary));
        deviceName.setTextSize(14);
        deviceName.setMaxLines(1);
        deviceName.setEllipsize(android.text.TextUtils.TruncateAt.END);

        TextView deviceState = new TextView(this);
        deviceState.setText(state);
        deviceState.setTextColor(getColor(connected ? R.color.success : R.color.text_secondary));
        deviceState.setTextSize(11);
        deviceState.setPadding(0, dp(3), 0, 0);

        copy.addView(deviceName);
        copy.addView(deviceState);
        row.addView(copy);

        TextView icon = new TextView(this);
        icon.setText("◉");
        icon.setTextColor(getColor(connected ? R.color.success : R.color.accent_light));
        icon.setTextSize(20);
        icon.setGravity(Gravity.CENTER);
        row.addView(icon, new LinearLayout.LayoutParams(dp(30), dp(30)));

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.bottomMargin = dp(7);
        devicesContainer.addView(row, params);
    }

    private void openBluetoothSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        } catch (Exception exception) {
            Toast.makeText(this, "Não foi possível abrir as configurações Bluetooth.", Toast.LENGTH_SHORT).show();
        }
    }

    private void chooseMusic() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("audio/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(intent, REQUEST_AUDIO_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_AUDIO_FILE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            String name = getDisplayName(uri);
            loadAudio(uri, name);
        }
    }

    private String getDisplayName(Uri uri) {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    String value = cursor.getString(index);
                    if (value != null && !value.trim().isEmpty()) return value;
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return "Áudio selecionado";
    }

    private void loadAudio(Uri uri, String name) {
        releasePlayer();
        trackName.setText(name);
        playPauseButton.setEnabled(false);
        playPauseButton.setText("Carregando…");

        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build());
        mediaPlayer.setOnPreparedListener(player -> {
            playerPrepared = true;
            playPauseButton.setEnabled(true);
            player.start();
            playPauseButton.setText("Pausar");
        });
        mediaPlayer.setOnCompletionListener(player -> playPauseButton.setText("Reproduzir"));
        mediaPlayer.setOnErrorListener((player, what, extra) -> {
            playPauseButton.setText("Reproduzir");
            playPauseButton.setEnabled(false);
            Toast.makeText(this, "Não foi possível reproduzir este arquivo.", Toast.LENGTH_SHORT).show();
            releasePlayer();
            return true;
        });

        try {
            mediaPlayer.setDataSource(this, uri);
            mediaPlayer.prepareAsync();
        } catch (IOException | SecurityException exception) {
            releasePlayer();
            playPauseButton.setText("Reproduzir");
            Toast.makeText(this, "Falha ao abrir o arquivo de áudio.", Toast.LENGTH_SHORT).show();
        }
    }

    private void togglePlayback() {
        if (mediaPlayer == null || !playerPrepared) return;
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            playPauseButton.setText("Reproduzir");
        } else {
            mediaPlayer.start();
            playPauseButton.setText("Pausar");
        }
    }

    private void releasePlayer() {
        playerPrepared = false;
        if (mediaPlayer != null) {
            try {
                mediaPlayer.setOnPreparedListener(null);
                mediaPlayer.setOnCompletionListener(null);
                mediaPlayer.setOnErrorListener(null);
                mediaPlayer.stop();
            } catch (Exception ignored) {
            }
            try {
                mediaPlayer.release();
            } catch (Exception ignored) {
            }
            mediaPlayer = null;
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        releasePlayer();
        if (bluetoothAdapter != null && a2dpProxy != null && hasBluetoothPermission()) {
            try {
                bluetoothAdapter.closeProfileProxy(BluetoothProfile.A2DP, a2dpProxy);
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }
}
