plugins {
    id("com.android.application")
}

android {
    namespace = "com.duotune.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.duotune.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
